<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Compte;
use App\Entity\Client;

class CompteController extends AbstractController
{
    #[Route('/compte', name: 'app_compte')]
    public function index(): Response
    {
        return $this->render('compte/index.html.twig', [
            'controller_name' => 'CompteController',
        ]);
    }
    #[Route('/add-compte', name: 'make_compte')]
    public function makeCompte(CompteRepository $repo,
    EntityManagerInterface $em): Response
    {
        if (!$this->getUser()) {
            return $this->redirectToRoute('app_login');
        }
    
        if($compte!=null){
            $compte = new Compte;
            $commande->setNumero;
        
    #[Route('/list-compte', name: 'view_compte')]
    public function viewCompte(CompteRepository $repo,
    EntityManagerInterface $em): Response
    {
        if (!$this->getUser()) {
                return $this->redirectToRoute('app_login');
            }
            
                if($compte!=null){
                    $compte = new Compte;
                    $commande->setNumero;
                       
                             
          
}
}
}