<?php

namespace App\Entity;

use App\Repository\ClientRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ClientRepository::class)
 */
class Client
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    public function getId(): ?int
    {
        return $this->id;
    }
     /**
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

  
    /**
     * @ORM\Column(type="string")
     */
    private $prenom;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getnom(): ?string
    {
        return $this->nom;
    }

    public function setNumero(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }


}
