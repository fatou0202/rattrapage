
namespace WindowsFormsApp1.dao.ado.net
{
     using System;
    using System.Collections.Generic;
    
    public partial class users_gc
    {
        
    
        public int ID { get; set; }
        public string nom{ get; set; }
        public string prenom{ get; set; }
        public Nullable<int> role_user { get; set; }
      
        public string solde { get; set; }
    
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<compte> comptes { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<livraison> livraisons { get; set; }
        public virtual role role { get; set; }
        override
        public string ToString()
        {
            return nomAndprenom;
        }
    }
   
}
