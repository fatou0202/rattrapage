

namespace WindowsFormsApp1.dao.ado.net
{
   using System;
    using System.Collections.Generic;
    
    public partial class Cheque: CompteS
    {
        
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
       
       public compte()
        {
            this.depot = new HashSet<depot>();
           

        }
    
        private string frais { get; set; }
        
       
}
