﻿

namespace WindowsFormsApp1.dao.ado.net
{
    public class Client
    {
        private string nom;
        private string prenom;
        //OneToMany
        private List<Compte> comptes;
      
        //porpietes
        public string Nom { get => nom; set => nom; }
        public string Adresse { get => prenom; set => prenom ; }
        public List<Compte> Comptes { get => comptes; set => comptes = value; }
    }
}


