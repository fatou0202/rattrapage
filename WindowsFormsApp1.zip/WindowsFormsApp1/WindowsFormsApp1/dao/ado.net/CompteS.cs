﻿

namespace WindowsFormsApp1.dao.ado.net
{
   using System;
    using System.Collections.Generic;
    
    public partial class compte
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public compte()
        {
            this.depot = new HashSet<depot>();
            this.retrait = new HashSet<retrait>();
            this.consultation = new HashSet<consultation>();
            this.virement = new HashSet<virement>();

        }
    
        public int ID { get; set; }
        public int id { get; set; }
        public int solde { get; set; }
        public Nullable<int> client_id { get; set; }
        public string retrait { get; set; }
        public string depot { get; set; }
        
        public string consultation { get; set; }   
        public string virement { get; set; }
    
        public virtual ICollection<depot> depot { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<virement> virements { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        
        public virtual ICollection<retrait> retraits { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<consultation> consultations { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
    }
}

