

namespace WindowsFormsApp1.dao.ado.net
{
  using System;
    using System.Collections.Generic;
    
    public partial class Epargne: CompteS
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
       
    
        private DateTime Dbdate = DateTime;
         private DateTime dateFin = DateTime;
          private float taux;
       
    
    }
}