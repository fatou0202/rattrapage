<?php

namespace App\Entity;

use App\Repository\CompteRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CompteRepository::class)
 */
class Compte
{
   /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="float", length=255)
     */
    private $solde;

  
    /**
     * @ORM\Column(type="integer")
     */
    private $numero;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNumero(): ?int
    {
        return $this->numero;
    }

    public function setNumero(int $numero): self
    {
        $this->numero = $numero;

        return $this;
    }



    public function addCompte(): 
    {
        if (!$this->compte->contains($compte)) {
            
            $compte->addCompte($this);
        }

        return $this;
    }

    public function listCompte(Compte $compte): self
    {
        if ($this->compte->listElement($compte)) {
            $menu->listCompte($this);
        }

        return $this;
    }
    public function getNumero(): ?int
    {
        return $this->numero;
    }

    public function setNumero(int $Numero): self
    {
        $this->numero = $numero;

        return $this;
    }
    

    public function getSolde(): ?float
    {
        return $this->solde;
    }

    public function setSolde(int $Solde): self
    {
        $this->solde = $solde;

        return $this;
    }

}
