using System.ComponentModel.DataAnnotations.Schema;
using WindowsFormsApp1.dao.ado.net;

namespace WindowsFormsApp1.models
{
    [Table("compte")]
    public class Compte
    {
        public int CompteId { get; set; }
        public int ClientId{ get; set; }

        public compte cmt { get; set; }
        public client clt { get; set; }

    }
}
