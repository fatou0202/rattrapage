<?php

namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class Compte extends Fixture
{
    
    
        public function load(ObjectManager $manager): void
        {
    
           
            
           
                $data=new Compte;
                $data->setNumero();
                $data->setSolde();
                
               
            


        $manager->flush();
    }
}
