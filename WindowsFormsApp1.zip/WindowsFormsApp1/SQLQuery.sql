CREATE TABLE [dbo].[compte] (
    [compte_id] INT            NULL,
    [client_id] INT            NULL,
    FOREIGN KEY ([compte_id]) REFERENCES [dbo].[compte] ([ID]),
    FOREIGN KEY ([client_id]) REFERENCES [dbo].[client] ([ID])
);

